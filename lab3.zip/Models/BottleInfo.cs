﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lab3.Models
{
    public class BottleInfo
    {
        [Required]
        [Range(50.0, 100.0)]
        public int numBottles
        {
            get;
            set;
        }
    }
}
